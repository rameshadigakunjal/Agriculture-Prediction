export interface PredictionFormData {
  district: string;
  year: string;
  production: string;
  rainfall: string;
  temperature: string;
  humidity: string;
}

export interface PredictionResult {
  riceYield: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  inputData: PredictionFormData;
  timestamp: string;
}

export interface MLPredictions {
  p1Result: {
    district: string;
    year: number;
    production: number;
    predictedYield: number;
  };
  p2Result: {
    rainfall: number;
    temperature: number;
    humidity: number;
    nitrogen: number;
    phosphorus: number;
    potassium: number;
  };
  finalResult: {
    riceYield: number;
    nitrogen: number;
    phosphorus: number;
    potassium: number;
  };
}