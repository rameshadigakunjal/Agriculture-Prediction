import { PredictionResult } from '../types';

export const downloadPredictionCSV = (result: PredictionResult) => {
  const csvData = [
    ['Parameter', 'Value', 'Unit'],
    ['District', result.inputData.district, ''],
    ['Year', result.inputData.year, ''],
    ['Production', result.inputData.production, 'tons'],
    ['Rainfall', result.inputData.rainfall, 'mm'],
    ['Temperature', result.inputData.temperature, '°C'],
    ['Humidity', result.inputData.humidity, '%'],
    ['', '', ''],
    ['PREDICTIONS', '', ''],
    ['Rice Yield', result.riceYield.toString(), 'tons/ha'],
    ['Nitrogen (N)', result.nitrogen.toString(), 'kg/ha'],
    ['Phosphorus (P)', result.phosphorus.toString(), 'kg/ha'],
    ['Potassium (K)', result.potassium.toString(), 'kg/ha'],
    ['', '', ''],
    ['Generated on', result.timestamp, '']
  ];

  const csvContent = csvData.map(row => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `rice-prediction-${Date.now()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};