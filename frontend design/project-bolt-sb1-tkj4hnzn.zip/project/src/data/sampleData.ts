export const districts = [
  'West Bengal', 'Punjab', 'Uttar Pradesh', 'Tamil Nadu', 'Andhra Pradesh',
  'Karnataka', 'Odisha', 'Bihar', 'Haryana', 'Maharashtra'
];

export const sampleP1Data = [
  { district: 'West Bengal', cropYear: 2022, production: 15000, yield: 3.2 },
  { district: 'Punjab', cropYear: 2022, production: 11000, yield: 4.1 },
  { district: 'Uttar Pradesh', cropYear: 2022, production: 13000, yield: 2.8 },
  { district: 'Tamil Nadu', cropYear: 2022, production: 8000, yield: 3.5 },
];

export const sampleP2Data = [
  { rainfall: 1200, temperature: 28, humidity: 75, n: 120, p: 60, k: 40 },
  { rainfall: 800, temperature: 32, humidity: 65, n: 100, p: 45, k: 35 },
  { rainfall: 1500, temperature: 26, humidity: 80, n: 140, p: 70, k: 50 },
];