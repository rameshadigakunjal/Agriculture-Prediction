export const districts = [
  'Tumkur',
  'Davangere',
  'Mysore',
  'Mandya',
  'Hassan',
  'Shimoga',
  'Chitradurga',
  'Bellary',
  'Raichur',
  'Bijapur',
  'Bagalkot',
  'Haveri',
  'Dharwad',
  'Gadag',
  'Koppal',
  'Yadgir',
  'Kalaburagi',
  'Bidar',
  'Chamarajanagar',
  'Kodagu'
];

export const years = [
  '2020',
  '2021',
  '2022',
  '2023',
  '2024',
  '2025'
];