import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { BarChart3, Download, ArrowLeft, CheckCircle, Leaf, Beaker } from 'lucide-react';
import { PredictionFormData, PredictionResult } from '../types';
import { predictionService } from '../services/predictionService';
import { downloadPredictionCSV } from '../utils/csvExport';

const ResultPage: React.FC = () => {
  const navigate = useNavigate();
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadPrediction = async () => {
      try {
        const formDataStr = sessionStorage.getItem('predictionFormData');
        if (!formDataStr) {
          navigate('/predict');
          return;
        }

        const formData: PredictionFormData = JSON.parse(formDataStr);
        const predictions = await predictionService.predictAll(formData);

        const predictionResult: PredictionResult = {
          riceYield: predictions.finalResult.riceYield,
          nitrogen: predictions.finalResult.nitrogen,
          phosphorus: predictions.finalResult.phosphorus,
          potassium: predictions.finalResult.potassium,
          inputData: formData,
          timestamp: new Date().toLocaleString()
        };

        setResult(predictionResult);
      } catch (err) {
        setError('Failed to generate predictions. Please try again.');
        console.error('Prediction error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadPrediction();
  }, [navigate]);

  const handleDownload = () => {
    if (result) {
      downloadPredictionCSV(result);
    }
  };

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto text-center py-16">
        <div className="bg-white rounded-2xl shadow-lg p-12">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-green-600 mx-auto mb-6"></div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Processing Your Data</h2>
          <p className="text-gray-600">
            Our advanced ML models are analyzing your inputs to generate accurate predictions...
          </p>
          <div className="mt-8 space-y-2 text-sm text-gray-500">
            <p>✓ Running multilinear regression model...</p>
            <p>✓ Applying support vector regression...</p>
            <p>✓ Computing hybrid predictions...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto text-center py-16">
        <div className="bg-white rounded-2xl shadow-lg p-12">
          <div className="text-red-500 mb-6">
            <BarChart3 className="h-16 w-16 mx-auto" />
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Prediction Error</h2>
          <p className="text-gray-600 mb-8">{error}</p>
          <Link
            to="/predict"
            className="inline-flex items-center space-x-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Try Again</span>
          </Link>
        </div>
      </div>
    );
  }

  if (!result) {
    return null;
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center space-x-3 mb-6">
          <div className="bg-green-100 p-3 rounded-full">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800">
            Prediction Results
          </h1>
        </div>
        <p className="text-xl text-gray-600">
          Based on your farming data, here are the AI-generated predictions
        </p>
      </div>

      {/* Main Results */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Rice Yield Prediction */}
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8 border border-green-200">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-green-600 p-3 rounded-lg">
              <Leaf className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-green-800">Predicted Rice Yield</h2>
              <p className="text-green-600">Final optimized prediction</p>
            </div>
          </div>
          
          <div className="text-center py-8">
            <div className="text-6xl font-bold text-green-700 mb-2">
              {result.riceYield}
            </div>
            <div className="text-xl text-green-600 font-semibold">
              tons/hectare
            </div>
          </div>

          <div className="bg-white/50 rounded-lg p-4">
            <p className="text-sm text-green-700 text-center">
              This prediction combines multilinear regression, climate analysis, 
              and soil nutrient optimization for maximum accuracy.
            </p>
          </div>
        </div>

        {/* Soil Nutrients */}
        <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-200">
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-blue-600 p-3 rounded-lg">
              <Beaker className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-blue-800">Required Soil Nutrients</h2>
              <p className="text-blue-600">Optimal NPK levels</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-yellow-100 rounded-lg p-4 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-yellow-800">Nitrogen (N)</h3>
                <p className="text-sm text-yellow-600">Essential for leaf growth</p>
              </div>
              <div className="text-2xl font-bold text-yellow-700">
                {result.nitrogen} <span className="text-sm font-normal">kg/ha</span>
              </div>
            </div>

            <div className="bg-orange-100 rounded-lg p-4 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-orange-800">Phosphorus (P)</h3>
                <p className="text-sm text-orange-600">Promotes root development</p>
              </div>
              <div className="text-2xl font-bold text-orange-700">
                {result.phosphorus} <span className="text-sm font-normal">kg/ha</span>
              </div>
            </div>

            <div className="bg-purple-100 rounded-lg p-4 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-purple-800">Potassium (K)</h3>
                <p className="text-sm text-purple-600">Enhances disease resistance</p>
              </div>
              <div className="text-2xl font-bold text-purple-700">
                {result.potassium} <span className="text-sm font-normal">kg/ha</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Input Summary */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-6">Input Summary</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-2">Location & Time</h4>
            <p className="text-gray-600">District: <strong>{result.inputData.district}</strong></p>
            <p className="text-gray-600">Year: <strong>{result.inputData.year}</strong></p>
            <p className="text-gray-600">Production: <strong>{result.inputData.production} tons</strong></p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-2">Climate Data</h4>
            <p className="text-gray-600">Rainfall: <strong>{result.inputData.rainfall} mm</strong></p>
            <p className="text-gray-600">Temperature: <strong>{result.inputData.temperature}°C</strong></p>
            <p className="text-gray-600">Humidity: <strong>{result.inputData.humidity}%</strong></p>
          </div>
          
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="font-semibold text-gray-700 mb-2">Generated</h4>
            <p className="text-gray-600">Timestamp: <strong>{result.timestamp}</strong></p>
            <p className="text-gray-600">Model: <strong>Hybrid ML Pipeline</strong></p>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button
          onClick={handleDownload}
          className="flex items-center justify-center space-x-2 bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold"
        >
          <Download className="h-5 w-5" />
          <span>Download Report (CSV)</span>
        </button>
        
        <Link
          to="/predict"
          className="flex items-center justify-center space-x-2 bg-green-600 text-white px-8 py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold"
        >
          <BarChart3 className="h-5 w-5" />
          <span>New Prediction</span>
        </Link>
      </div>
    </div>
  );
};

export default ResultPage;