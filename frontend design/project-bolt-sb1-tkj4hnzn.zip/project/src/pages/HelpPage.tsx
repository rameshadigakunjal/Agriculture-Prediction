import React from 'react';
import { HelpCircle, Info, MapPin, Calendar, Package, CloudRain, Thermometer, Droplets, Leaf, Beaker } from 'lucide-react';

const HelpPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-12">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center space-x-3 mb-6">
          <div className="bg-blue-100 p-3 rounded-full">
            <HelpCircle className="h-8 w-8 text-blue-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800">
            Help & Instructions
          </h1>
        </div>
        <p className="text-xl text-gray-600">
          Learn how to use the Rice Yield Prediction system effectively
        </p>
      </div>

      {/* Input Fields Guide */}
      <section className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-2">
          <Info className="h-6 w-6 text-blue-600" />
          <span>Input Field Explanations</span>
        </h2>

        <div className="space-y-8">
          {/* Basic Information */}
          <div>
            <h3 className="text-xl font-semibold text-gray-700 mb-4">Basic Information</h3>
            <div className="grid md:grid-cols-1 gap-6">
              <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                <MapPin className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-800">District</h4>
                  <p className="text-gray-600 mt-1">
                    Select your farming district from the dropdown. This helps the model account for 
                    regional soil conditions, climate patterns, and agricultural practices specific to your area.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                <Calendar className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-800">Year</h4>
                  <p className="text-gray-600 mt-1">
                    Choose the crop year for your prediction. This accounts for year-over-year improvements 
                    in farming techniques, seed varieties, and changing climate patterns.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                <Package className="h-6 w-6 text-amber-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-800">Production (tons)</h4>
                  <p className="text-gray-600 mt-1">
                    <strong>What is Production?</strong> This refers to the total amount of rice you expect 
                    to harvest from your entire farming area, measured in metric tons. For example, if you 
                    farm 10 hectares and expect 3 tons per hectare, enter 30 tons.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Climate Data */}
          <div>
            <h3 className="text-xl font-semibold text-gray-700 mb-4">Climate Data</h3>
            <div className="grid md:grid-cols-1 gap-6">
              <div className="flex items-start space-x-4 p-4 bg-blue-50 rounded-lg">
                <CloudRain className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-800">Rainfall (mm)</h4>
                  <p className="text-gray-600 mt-1">
                    <strong>How to measure:</strong> Enter the total rainfall expected during the growing 
                    season (typically 4-6 months). You can get this data from local weather stations, 
                    meteorological departments, or weather apps. Normal range: 300-1500mm.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-4 bg-red-50 rounded-lg">
                <Thermometer className="h-6 w-6 text-red-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-800">Temperature (°C)</h4>
                  <p className="text-gray-600 mt-1">
                    <strong>How to measure:</strong> Enter the average temperature during the growing season. 
                    This should be the mean of daily maximum and minimum temperatures. Optimal range for 
                    rice: 20-35°C. Use local weather data or meteorological forecasts.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-4 bg-cyan-50 rounded-lg">
                <Droplets className="h-6 w-6 text-cyan-600 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-800">Humidity (%)</h4>
                  <p className="text-gray-600 mt-1">
                    <strong>How to measure:</strong> Average relative humidity during the growing season. 
                    This affects plant transpiration and disease susceptibility. Normal range: 50-90%. 
                    Available from weather stations or humidity meters.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Understanding Results */}
      <section className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center space-x-2">
          <BarChart3 className="h-6 w-6 text-green-600" />
          <span>Understanding Your Results</span>
        </h2>

        <div className="space-y-6">
          <div className="flex items-start space-x-4 p-4 bg-green-50 rounded-lg">
            <Leaf className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-800">Rice Yield (tons/hectare)</h4>
              <p className="text-gray-600 mt-1">
                <strong>What is Yield?</strong> This is the amount of rice you can expect to harvest per 
                hectare of land. It's calculated by dividing total production by total farming area. 
                Average yields in India range from 2-6 tons/hectare depending on conditions.
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-4 p-4 bg-purple-50 rounded-lg">
            <Beaker className="h-6 w-6 text-purple-600 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-gray-800">NPK Requirements (kg/hectare)</h4>
              <p className="text-gray-600 mt-1">
                <strong>Nitrogen (N):</strong> Essential for leaf growth and green color. Deficiency causes yellowing.<br/>
                <strong>Phosphorus (P):</strong> Important for root development and grain formation.<br/>
                <strong>Potassium (K):</strong> Enhances disease resistance and grain quality.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Units Reference */}
      <section className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Units Reference</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Input Units</h3>
            <ul className="space-y-2 text-gray-600">
              <li><strong>Production:</strong> Metric tons (1000 kg)</li>
              <li><strong>Rainfall:</strong> Millimeters (mm)</li>
              <li><strong>Temperature:</strong> Degrees Celsius (°C)</li>
              <li><strong>Humidity:</strong> Percentage (%)</li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-700">Output Units</h3>
            <ul className="space-y-2 text-gray-600">
              <li><strong>Yield:</strong> Tons per hectare (tons/ha)</li>
              <li><strong>Nutrients:</strong> Kilograms per hectare (kg/ha)</li>
              <li><strong>Area:</strong> 1 hectare = 2.47 acres</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Tips for Better Predictions */}
      <section className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-8 border border-green-200">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Tips for Better Predictions</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold text-green-800 mb-3">Data Accuracy</h3>
            <ul className="space-y-2 text-green-700">
              <li>• Use recent weather data from reliable sources</li>
              <li>• Consider seasonal variations in your inputs</li>
              <li>• Account for irrigation when estimating rainfall</li>
              <li>• Use average values for variable conditions</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-green-800 mb-3">Best Practices</h3>
            <ul className="space-y-2 text-green-700">
              <li>• Run predictions for different scenarios</li>
              <li>• Compare results with historical yields</li>
              <li>• Consider local farming practices</li>
              <li>• Consult with agricultural experts</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HelpPage;