import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Leaf, BarChart3, Beaker, TrendingUp, Users, Award, Globe } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center py-16">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <div className="bg-green-100 p-3 rounded-full">
              <Leaf className="h-8 w-8 text-green-600" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-800">
              Rice Yield & Soil Nutrient Predictor
            </h1>
          </div>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
            Get instant predictions on expected rice yield and required NPK levels 
            based on your farming data using advanced machine learning models.
          </p>
          
          <Link
            to="/predict"
            className="inline-flex items-center space-x-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:from-green-700 hover:to-emerald-700 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <span>Predict Now</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Advanced ML Pipeline
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our three-phase prediction system combines multiple machine learning models 
            to provide accurate and reliable agricultural insights.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <BarChart3 className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Phase 1: Rice Yield</h3>
            <p className="text-gray-600 mb-4">
              Multilinear regression model predicts rice yield based on district, 
              crop year, and production data.
            </p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>• District-specific factors</li>
              <li>• Historical production analysis</li>
              <li>• Year-over-year trends</li>
            </ul>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="bg-purple-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <Beaker className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Phase 2: Soil Nutrients</h3>
            <p className="text-gray-600 mb-4">
              Support Vector Regression predicts optimal NPK levels based on 
              climate conditions.
            </p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>• Rainfall impact analysis</li>
              <li>• Temperature optimization</li>
              <li>• Humidity correlation</li>
            </ul>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
            <div className="bg-amber-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <TrendingUp className="h-8 w-8 text-amber-600" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Phase 3: Final Prediction</h3>
            <p className="text-gray-600 mb-4">
              Hybrid stacked model combines all factors for the most accurate 
              final yield prediction.
            </p>
            <ul className="text-sm text-gray-500 space-y-2">
              <li>• Multi-model ensemble</li>
              <li>• Comprehensive analysis</li>
              <li>• Optimized accuracy</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gradient-to-r from-green-50 to-emerald-50 rounded-3xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Why Choose AgriPredict?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Empowering farmers with data-driven insights for better crop management and higher yields.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-green-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Users className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Farmer-Friendly</h3>
            <p className="text-gray-600">Simple interface designed for farmers of all technical backgrounds</p>
          </div>

          <div className="text-center">
            <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Award className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Accurate Predictions</h3>
            <p className="text-gray-600">Advanced ML models trained on comprehensive agricultural datasets</p>
          </div>

          <div className="text-center">
            <div className="bg-purple-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Globe className="h-8 w-8 text-purple-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Regional Focus</h3>
            <p className="text-gray-600">Specialized for Karnataka districts with local climate considerations</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center py-16">
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 rounded-3xl p-12 text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Optimize Your Rice Yield?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Start making data-driven decisions for your farm today.
          </p>
          <Link
            to="/predict"
            className="inline-flex items-center space-x-3 bg-white text-green-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-50 transform hover:scale-105 transition-all duration-200 shadow-lg"
          >
            <span>Get Started</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;