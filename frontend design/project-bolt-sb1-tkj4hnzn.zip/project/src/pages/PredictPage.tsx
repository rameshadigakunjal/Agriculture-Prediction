import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calculator, MapPin, Calendar, Package, CloudRain, Thermometer, Droplets } from 'lucide-react';
import { PredictionFormData } from '../types';
import { districts, years } from '../data/districts';

const PredictPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<PredictionFormData>({
    district: '',
    year: '',
    production: '',
    rainfall: '',
    temperature: '',
    humidity: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof PredictionFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    const requiredFields = Object.values(formData);
    if (requiredFields.some(field => !field.trim())) {
      alert('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    // Store form data in sessionStorage for the results page
    sessionStorage.setItem('predictionFormData', JSON.stringify(formData));
    
    // Navigate to results page
    navigate('/result');
  };

  const isFormValid = Object.values(formData).every(field => field.trim() !== '');

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center space-x-3 mb-6">
          <div className="bg-green-100 p-3 rounded-full">
            <Calculator className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800">
            Rice Yield Prediction
          </h1>
        </div>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Enter your farming data below to get accurate predictions for rice yield and required soil nutrients.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
        {/* Basic Information Section */}
        <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 border-b border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-800 mb-2">Basic Information</h2>
          <p className="text-gray-600">Location and production details</p>
        </div>

        <div className="p-8 space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                <MapPin className="h-4 w-4 text-green-600" />
                <span>District</span>
              </label>
              <select
                value={formData.district}
                onChange={(e) => handleInputChange('district', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                required
              >
                <option value="">Select District</option>
                {districts.map((district) => (
                  <option key={district} value={district}>
                    {district}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                <Calendar className="h-4 w-4 text-blue-600" />
                <span>Year</span>
              </label>
              <select
                value={formData.year}
                onChange={(e) => handleInputChange('year', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                required
              >
                <option value="">Select Year</option>
                {years.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                <Package className="h-4 w-4 text-amber-600" />
                <span>Production (tons)</span>
              </label>
              <input
                type="number"
                value={formData.production}
                onChange={(e) => handleInputChange('production', e.target.value)}
                placeholder="e.g., 5000"
                min="1"
                step="1"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                required
              />
            </div>
          </div>
        </div>

        {/* Climate Data Section */}
        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 border-b border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-800 mb-2">Climate Data</h2>
          <p className="text-gray-600">Environmental conditions for your area</p>
        </div>

        <div className="p-8 space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                <CloudRain className="h-4 w-4 text-blue-600" />
                <span>Rainfall (mm)</span>
              </label>
              <input
                type="number"
                value={formData.rainfall}
                onChange={(e) => handleInputChange('rainfall', e.target.value)}
                placeholder="e.g., 300"
                min="0"
                step="1"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                <Thermometer className="h-4 w-4 text-red-600" />
                <span>Temperature (°C)</span>
              </label>
              <input
                type="number"
                value={formData.temperature}
                onChange={(e) => handleInputChange('temperature', e.target.value)}
                placeholder="e.g., 28"
                min="0"
                max="50"
                step="0.1"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="flex items-center space-x-2 text-sm font-semibold text-gray-700 mb-3">
                <Droplets className="h-4 w-4 text-cyan-600" />
                <span>Humidity (%)</span>
              </label>
              <input
                type="number"
                value={formData.humidity}
                onChange={(e) => handleInputChange('humidity', e.target.value)}
                placeholder="e.g., 70"
                min="0"
                max="100"
                step="1"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                required
              />
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="p-8 bg-gray-50 border-t border-gray-200">
          <button
            type="submit"
            disabled={!isFormValid || isLoading}
            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 px-8 rounded-xl font-semibold text-lg hover:from-green-700 hover:to-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-[1.02] transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isLoading ? 'Processing...' : 'Get Prediction'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PredictPage;