import React from 'react';
import { Wheat, Leaf } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-green-600 to-green-700 text-white shadow-lg">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-white/20 p-2 rounded-lg">
              <Wheat className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">AgriPredict</h1>
              <p className="text-green-100 text-sm md:text-base">
                Rice Yield Prediction System
              </p>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-2">
            <Leaf className="h-5 w-5 text-green-200" />
            <span className="text-green-100">Smart Agriculture</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;