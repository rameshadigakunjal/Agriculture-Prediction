import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Wheat, Home, Calculator, BarChart3, HelpCircle } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50">
      <header className="bg-gradient-to-r from-green-600 to-emerald-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-3 hover:opacity-90 transition-opacity">
              <div className="bg-white/20 p-2 rounded-lg">
                <Wheat className="h-8 w-8" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold">AgriPredict</h1>
                <p className="text-green-100 text-sm">Rice Yield & Soil Nutrient Predictor</p>
              </div>
            </Link>
            
            <nav className="hidden md:flex items-center space-x-6">
              <Link
                to="/"
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  isActive('/') ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                <Home className="h-4 w-4" />
                <span>Home</span>
              </Link>
              <Link
                to="/predict"
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  isActive('/predict') ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                <Calculator className="h-4 w-4" />
                <span>Predict</span>
              </Link>
              <Link
                to="/help"
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  isActive('/help') ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                <HelpCircle className="h-4 w-4" />
                <span>Help</span>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {children}
      </main>

      <footer className="bg-gray-800 text-white py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Wheat className="h-5 w-5 text-green-400" />
            <span className="text-gray-300">Powered by Advanced Machine Learning</span>
          </div>
          <p className="text-sm text-gray-400">
            AgriPredict © 2024 - Transforming Agriculture through Data Science
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;