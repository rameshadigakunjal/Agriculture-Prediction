import React, { useState } from 'react';
import { TrendingUp } from 'lucide-react';
import PredictionCard from './PredictionCard';
import InputField from './InputField';
import ResultDisplay from './ResultDisplay';
import { P3FormData, P3Prediction } from '../types';
import { mlService } from '../services/mlService';
import { downloadCSV } from '../utils/csvExport';
import { districts } from '../data/sampleData';

const P3FinalYield: React.FC = () => {
  const [formData, setFormData] = useState<P3FormData>({
    district: '',
    cropYear: '',
    production: '',
    nitrogen: '',
    phosphorus: '',
    potassium: '',
    rainfall: '',
    temperature: '',
    humidity: ''
  });
  const [predictions, setPredictions] = useState<P3Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof P3FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePredict = async () => {
    const requiredFields = Object.values(formData);
    if (requiredFields.some(field => !field)) {
      alert('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const prediction = mlService.predictFinalYield(
      formData.district,
      parseInt(formData.cropYear),
      parseFloat(formData.production),
      parseFloat(formData.nitrogen),
      parseFloat(formData.phosphorus),
      parseFloat(formData.potassium),
      parseFloat(formData.rainfall),
      parseFloat(formData.temperature),
      parseFloat(formData.humidity)
    );
    
    setPredictions(prev => [...prev, prediction]);
    setIsLoading(false);
  };

  const handleDownload = () => {
    downloadCSV(predictions, 'final-yield-predictions.csv');
  };

  return (
    <PredictionCard
      title="Phase 3: Final Rice Yield Estimation"
      description="Hybrid Stacked Regression Model"
      icon={TrendingUp}
    >
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <div className="md:col-span-3">
          <h4 className="text-lg font-semibold text-gray-700 mb-4">Basic Information</h4>
        </div>
        
        <InputField
          label="District"
          type="select"
          value={formData.district}
          onChange={(value) => handleInputChange('district', value)}
          options={districts}
        />
        <InputField
          label="Crop Year"
          type="number"
          value={formData.cropYear}
          onChange={(value) => handleInputChange('cropYear', value)}
          placeholder="e.g., 2024"
          min={2000}
          max={2030}
        />
        <InputField
          label="Production (tons)"
          type="number"
          value={formData.production}
          onChange={(value) => handleInputChange('production', value)}
          placeholder="e.g., 15000"
          min={0}
          step={100}
        />
        
        <div className="md:col-span-3 mt-4">
          <h4 className="text-lg font-semibold text-gray-700 mb-4">Soil Nutrients</h4>
        </div>
        
        <InputField
          label="Nitrogen (N)"
          type="number"
          value={formData.nitrogen}
          onChange={(value) => handleInputChange('nitrogen', value)}
          placeholder="e.g., 120"
          min={0}
          step={0.1}
        />
        <InputField
          label="Phosphorus (P)"
          type="number"
          value={formData.phosphorus}
          onChange={(value) => handleInputChange('phosphorus', value)}
          placeholder="e.g., 60"
          min={0}
          step={0.1}
        />
        <InputField
          label="Potassium (K)"
          type="number"
          value={formData.potassium}
          onChange={(value) => handleInputChange('potassium', value)}
          placeholder="e.g., 40"
          min={0}
          step={0.1}
        />
        
        <div className="md:col-span-3 mt-4">
          <h4 className="text-lg font-semibold text-gray-700 mb-4">Climate Data</h4>
        </div>
        
        <InputField
          label="Rainfall (mm)"
          type="number"
          value={formData.rainfall}
          onChange={(value) => handleInputChange('rainfall', value)}
          placeholder="e.g., 1200"
          min={0}
          max={3000}
          step={10}
        />
        <InputField
          label="Temperature (°C)"
          type="number"
          value={formData.temperature}
          onChange={(value) => handleInputChange('temperature', value)}
          placeholder="e.g., 28"
          min={0}
          max={50}
          step={0.1}
        />
        <InputField
          label="Humidity (%)"
          type="number"
          value={formData.humidity}
          onChange={(value) => handleInputChange('humidity', value)}
          placeholder="e.g., 75"
          min={0}
          max={100}
          step={1}
        />
      </div>
      
      <button
        onClick={handlePredict}
        disabled={isLoading}
        className="w-full bg-amber-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Computing Final Prediction...' : 'Predict Final Rice Yield'}
      </button>

      <ResultDisplay
        title="Final Predictions"
        results={predictions}
        onDownload={handleDownload}
      >
        {predictions.length === 0 ? (
          <p className="text-gray-500 text-center py-4">
            No predictions yet. Fill in all fields and click predict.
          </p>
        ) : (
          <div className="space-y-4">
            {predictions.map((prediction, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <div className="mb-6">
                  <div className="bg-gradient-to-r from-amber-100 to-yellow-100 p-4 rounded-lg text-center">
                    <p className="text-sm font-semibold text-amber-800 mb-2">
                      Final Predicted Rice Yield
                    </p>
                    <p className="text-3xl font-bold text-amber-900">
                      {prediction.finalYield} tons/hectare
                    </p>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
                  <div className="bg-gray-50 p-3 rounded">
                    <span className="font-semibold text-gray-600">District:</span>
                    <p className="text-gray-800">{prediction.district}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <span className="font-semibold text-gray-600">Year:</span>
                    <p className="text-gray-800">{prediction.cropYear}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded">
                    <span className="font-semibold text-gray-600">Production:</span>
                    <p className="text-gray-800">{prediction.production} tons</p>
                  </div>
                  <div className="bg-yellow-50 p-3 rounded">
                    <span className="font-semibold text-yellow-800">N:</span>
                    <p className="text-yellow-900">{prediction.nitrogen}</p>
                  </div>
                  <div className="bg-orange-50 p-3 rounded">
                    <span className="font-semibold text-orange-800">P:</span>
                    <p className="text-orange-900">{prediction.phosphorus}</p>
                  </div>
                  <div className="bg-purple-50 p-3 rounded">
                    <span className="font-semibold text-purple-800">K:</span>
                    <p className="text-purple-900">{prediction.potassium}</p>
                  </div>
                  <div className="bg-blue-50 p-3 rounded">
                    <span className="font-semibold text-blue-800">Rainfall:</span>
                    <p className="text-blue-900">{prediction.rainfall}mm</p>
                  </div>
                  <div className="bg-red-50 p-3 rounded">
                    <span className="font-semibold text-red-800">Temperature:</span>
                    <p className="text-red-900">{prediction.temperature}°C</p>
                  </div>
                  <div className="bg-cyan-50 p-3 rounded">
                    <span className="font-semibold text-cyan-800">Humidity:</span>
                    <p className="text-cyan-900">{prediction.humidity}%</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ResultDisplay>
    </PredictionCard>
  );
};

export default P3FinalYield;