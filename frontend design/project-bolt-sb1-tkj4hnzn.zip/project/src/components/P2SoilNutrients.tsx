import React, { useState } from 'react';
import { CloudRain, Thermometer, Droplets } from 'lucide-react';
import PredictionCard from './PredictionCard';
import InputField from './InputField';
import ResultDisplay from './ResultDisplay';
import { P2FormData, P2Prediction } from '../types';
import { mlService } from '../services/mlService';
import { downloadCSV } from '../utils/csvExport';

const P2SoilNutrients: React.FC = () => {
  const [formData, setFormData] = useState<P2FormData>({
    rainfall: '',
    temperature: '',
    humidity: ''
  });
  const [predictions, setPredictions] = useState<P2Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof P2FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePredict = async () => {
    if (!formData.rainfall || !formData.temperature || !formData.humidity) {
      alert('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const prediction = mlService.predictSoilNutrients(
      parseFloat(formData.rainfall),
      parseFloat(formData.temperature),
      parseFloat(formData.humidity)
    );
    
    setPredictions(prev => [...prev, prediction]);
    setIsLoading(false);
  };

  const handleDownload = () => {
    downloadCSV(predictions, 'soil-nutrient-predictions.csv');
  };

  return (
    <PredictionCard
      title="Phase 2: Soil Nutrient Prediction"
      description="Support Vector Regression Model"
      icon={CloudRain}
    >
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <InputField
          label="Rainfall (mm)"
          type="number"
          value={formData.rainfall}
          onChange={(value) => handleInputChange('rainfall', value)}
          placeholder="e.g., 1200"
          min={0}
          max={3000}
          step={10}
        />
        <InputField
          label="Temperature (°C)"
          type="number"
          value={formData.temperature}
          onChange={(value) => handleInputChange('temperature', value)}
          placeholder="e.g., 28"
          min={0}
          max={50}
          step={0.1}
        />
        <InputField
          label="Humidity (%)"
          type="number"
          value={formData.humidity}
          onChange={(value) => handleInputChange('humidity', value)}
          placeholder="e.g., 75"
          min={0}
          max={100}
          step={1}
        />
      </div>
      
      <button
        onClick={handlePredict}
        disabled={isLoading}
        className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Predicting...' : 'Predict Soil Nutrients'}
      </button>

      <ResultDisplay
        title="Predictions"
        results={predictions}
        onDownload={handleDownload}
      >
        {predictions.length === 0 ? (
          <p className="text-gray-500 text-center py-4">
            No predictions yet. Fill in the form and click predict.
          </p>
        ) : (
          <div className="space-y-3">
            {predictions.map((prediction, index) => (
              <div key={index} className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <CloudRain className="h-5 w-5 text-blue-500" />
                    <span className="text-sm text-gray-600">
                      Rainfall: <strong>{prediction.rainfall}mm</strong>
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Thermometer className="h-5 w-5 text-red-500" />
                    <span className="text-sm text-gray-600">
                      Temperature: <strong>{prediction.temperature}°C</strong>
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Droplets className="h-5 w-5 text-cyan-500" />
                    <span className="text-sm text-gray-600">
                      Humidity: <strong>{prediction.humidity}%</strong>
                    </span>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-3 gap-4 pt-4 border-t border-gray-200">
                  <div className="text-center">
                    <div className="bg-yellow-100 p-3 rounded-lg">
                      <p className="text-sm font-semibold text-yellow-800">Nitrogen (N)</p>
                      <p className="text-xl font-bold text-yellow-900">{prediction.nitrogen}</p>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="bg-orange-100 p-3 rounded-lg">
                      <p className="text-sm font-semibold text-orange-800">Phosphorus (P)</p>
                      <p className="text-xl font-bold text-orange-900">{prediction.phosphorus}</p>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="bg-purple-100 p-3 rounded-lg">
                      <p className="text-sm font-semibold text-purple-800">Potassium (K)</p>
                      <p className="text-xl font-bold text-purple-900">{prediction.potassium}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ResultDisplay>
    </PredictionCard>
  );
};

export default P2SoilNutrients;