import React from 'react';
import { Download } from 'lucide-react';

interface ResultDisplayProps {
  title: string;
  results: any[];
  onDownload: () => void;
  children: React.ReactNode;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({
  title,
  results,
  onDownload,
  children
}) => {
  return (
    <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-lg font-semibold text-gray-800">{title}</h4>
        {results.length > 0 && (
          <button
            onClick={onDownload}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
          >
            <Download className="h-4 w-4" />
            <span>Download CSV</span>
          </button>
        )}
      </div>
      {children}
    </div>
  );
};

export default ResultDisplay;