import React, { useState } from 'react';
import { BarChart3 } from 'lucide-react';
import PredictionCard from './PredictionCard';
import InputField from './InputField';
import ResultDisplay from './ResultDisplay';
import { P1FormData, P1Prediction } from '../types';
import { mlService } from '../services/mlService';
import { downloadCSV } from '../utils/csvExport';
import { districts } from '../data/sampleData';

const P1RiceYield: React.FC = () => {
  const [formData, setFormData] = useState<P1FormData>({
    district: '',
    cropYear: '',
    production: ''
  });
  const [predictions, setPredictions] = useState<P1Prediction[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: keyof P1FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePredict = async () => {
    if (!formData.district || !formData.cropYear || !formData.production) {
      alert('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const prediction = mlService.predictRiceYield(
      formData.district,
      parseInt(formData.cropYear),
      parseFloat(formData.production)
    );
    
    setPredictions(prev => [...prev, prediction]);
    setIsLoading(false);
  };

  const handleDownload = () => {
    downloadCSV(predictions, 'rice-yield-predictions.csv');
  };

  return (
    <PredictionCard
      title="Phase 1: Rice Yield Prediction"
      description="Multilinear Regression Model"
      icon={BarChart3}
    >
      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <InputField
          label="District"
          type="select"
          value={formData.district}
          onChange={(value) => handleInputChange('district', value)}
          options={districts}
        />
        <InputField
          label="Crop Year"
          type="number"
          value={formData.cropYear}
          onChange={(value) => handleInputChange('cropYear', value)}
          placeholder="e.g., 2024"
          min={2000}
          max={2030}
        />
        <InputField
          label="Production (tons)"
          type="number"
          value={formData.production}
          onChange={(value) => handleInputChange('production', value)}
          placeholder="e.g., 15000"
          min={0}
          step={100}
        />
      </div>
      
      <button
        onClick={handlePredict}
        disabled={isLoading}
        className="w-full bg-green-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'Predicting...' : 'Predict Rice Yield'}
      </button>

      <ResultDisplay
        title="Predictions"
        results={predictions}
        onDownload={handleDownload}
      >
        {predictions.length === 0 ? (
          <p className="text-gray-500 text-center py-4">
            No predictions yet. Fill in the form and click predict.
          </p>
        ) : (
          <div className="space-y-3">
            {predictions.map((prediction, index) => (
              <div key={index} className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="grid md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="font-semibold text-gray-600">District:</span>
                    <p className="text-gray-800">{prediction.district}</p>
                  </div>
                  <div>
                    <span className="font-semibold text-gray-600">Year:</span>
                    <p className="text-gray-800">{prediction.cropYear}</p>
                  </div>
                  <div>
                    <span className="font-semibold text-gray-600">Production:</span>
                    <p className="text-gray-800">{prediction.production} tons</p>
                  </div>
                  <div>
                    <span className="font-semibold text-green-600">Predicted Yield:</span>
                    <p className="text-green-800 font-bold text-lg">
                      {prediction.predictedYield} tons/hectare
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ResultDisplay>
    </PredictionCard>
  );
};

export default P1RiceYield;