import { P1Prediction, P2Prediction, P3Prediction } from '../types';
import { sampleP1Data, sampleP2Data } from '../data/sampleData';

class MLService {
  // Simulate multilinear regression for P1
  predictRiceYield(district: string, cropYear: number, production: number): P1Prediction {
    // Mock multilinear regression calculation
    const baseYield = 2.5;
    const districtFactor = this.getDistrictFactor(district);
    const yearFactor = (cropYear - 2020) * 0.1;
    const productionFactor = (production / 10000) * 0.3;
    
    const predictedYield = Math.max(0, baseYield + districtFactor + yearFactor + productionFactor);
    
    return {
      district,
      cropYear,
      production,
      predictedYield: Math.round(predictedYield * 100) / 100
    };
  }

  // Simulate SVR for P2
  predictSoilNutrients(rainfall: number, temperature: number, humidity: number): P2Prediction {
    // Mock SVR calculations with normalization
    const normalizedRainfall = Math.min(rainfall / 2000, 1);
    const normalizedTemp = Math.min(temperature / 45, 1);
    const normalizedHumidity = Math.min(humidity / 100, 1);
    
    const nitrogen = Math.round((80 + normalizedRainfall * 60 + normalizedHumidity * 40) * 100) / 100;
    const phosphorus = Math.round((30 + normalizedTemp * 40 + normalizedRainfall * 30) * 100) / 100;
    const potassium = Math.round((25 + normalizedHumidity * 35 + normalizedTemp * 25) * 100) / 100;
    
    return {
      rainfall,
      temperature,
      humidity,
      nitrogen,
      phosphorus,
      potassium
    };
  }

  // Simulate hybrid model for P3
  predictFinalYield(
    district: string,
    cropYear: number,
    production: number,
    nitrogen: number,
    phosphorus: number,
    potassium: number,
    rainfall: number,
    temperature: number,
    humidity: number
  ): P3Prediction {
    // Get P1 and P2 predictions
    const p1Result = this.predictRiceYield(district, cropYear, production);
    const p2Result = this.predictSoilNutrients(rainfall, temperature, humidity);
    
    // Combine predictions with hybrid model
    const baseYield = p1Result.predictedYield;
    const nutrientFactor = (nitrogen + phosphorus + potassium) / 300;
    const climateFactor = (rainfall / 1500) * (humidity / 100) * (35 - Math.abs(temperature - 28)) / 35;
    
    const finalYield = Math.max(0, baseYield * (1 + nutrientFactor * 0.3 + climateFactor * 0.2));
    
    return {
      district,
      cropYear,
      production,
      nitrogen,
      phosphorus,
      potassium,
      rainfall,
      temperature,
      humidity,
      finalYield: Math.round(finalYield * 100) / 100
    };
  }

  private getDistrictFactor(district: string): number {
    const factors: { [key: string]: number } = {
      'West Bengal': 0.8,
      'Punjab': 1.2,
      'Uttar Pradesh': 0.5,
      'Tamil Nadu': 0.9,
      'Andhra Pradesh': 0.7,
      'Karnataka': 0.6,
      'Odisha': 0.4,
      'Bihar': 0.3,
      'Haryana': 1.0,
      'Maharashtra': 0.6
    };
    return factors[district] || 0.5;
  }
}

export const mlService = new MLService();