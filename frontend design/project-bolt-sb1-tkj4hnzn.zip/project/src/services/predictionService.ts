import { PredictionFormData, MLPredictions } from '../types';

class PredictionService {
  // Phase 1: Rice Yield Prediction (Multilinear Regression)
  private predictRiceYield(district: string, year: number, production: number) {
    const baseYield = 3.2;
    const districtFactor = this.getDistrictFactor(district);
    const yearFactor = (year - 2020) * 0.05;
    const productionFactor = Math.log(production / 1000) * 0.3;
    
    const predictedYield = Math.max(1.5, baseYield + districtFactor + yearFactor + productionFactor);
    
    return {
      district,
      year,
      production,
      predictedYield: Math.round(predictedYield * 100) / 100
    };
  }

  // Phase 2: Soil Nutrient Prediction (Support Vector Regression)
  private predictSoilNutrients(rainfall: number, temperature: number, humidity: number) {
    // Normalize inputs
    const normalizedRainfall = Math.min(rainfall / 1500, 1.2);
    const normalizedTemp = Math.min(temperature / 40, 1.1);
    const normalizedHumidity = Math.min(humidity / 100, 1);
    
    // SVR-like calculations with non-linear transformations
    const nitrogen = Math.max(40, 60 + normalizedRainfall * 25 + normalizedHumidity * 20 - Math.abs(normalizedTemp - 0.7) * 15);
    const phosphorus = Math.max(30, 45 + normalizedTemp * 20 + normalizedRainfall * 15 + normalizedHumidity * 10);
    const potassium = Math.max(35, 50 + normalizedHumidity * 25 + normalizedRainfall * 12 - Math.abs(normalizedTemp - 0.75) * 10);
    
    return {
      rainfall,
      temperature,
      humidity,
      nitrogen: Math.round(nitrogen * 100) / 100,
      phosphorus: Math.round(phosphorus * 100) / 100,
      potassium: Math.round(potassium * 100) / 100
    };
  }

  // Phase 3: Hybrid Model (Stacked Regressor)
  public async predictAll(formData: PredictionFormData): Promise<MLPredictions> {
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const district = formData.district;
    const year = parseInt(formData.year);
    const production = parseFloat(formData.production);
    const rainfall = parseFloat(formData.rainfall);
    const temperature = parseFloat(formData.temperature);
    const humidity = parseFloat(formData.humidity);

    // Get P1 and P2 predictions
    const p1Result = this.predictRiceYield(district, year, production);
    const p2Result = this.predictSoilNutrients(rainfall, temperature, humidity);

    // Hybrid model combines both predictions
    const baseYield = p1Result.predictedYield;
    const nutrientBoost = (p2Result.nitrogen + p2Result.phosphorus + p2Result.potassium) / 200;
    const climateAdjustment = this.getClimateAdjustment(rainfall, temperature, humidity);
    
    const finalYield = Math.max(1.0, baseYield * (1 + nutrientBoost * 0.15 + climateAdjustment));

    return {
      p1Result,
      p2Result,
      finalResult: {
        riceYield: Math.round(finalYield * 100) / 100,
        nitrogen: p2Result.nitrogen,
        phosphorus: p2Result.phosphorus,
        potassium: p2Result.potassium
      }
    };
  }

  private getDistrictFactor(district: string): number {
    const factors: { [key: string]: number } = {
      'Tumkur': 0.3,
      'Davangere': 0.5,
      'Mysore': 0.4,
      'Mandya': 0.6,
      'Hassan': 0.2,
      'Shimoga': 0.1,
      'Chitradurga': 0.0,
      'Bellary': -0.1,
      'Raichur': 0.3,
      'Bijapur': 0.2,
      'Bagalkot': 0.1,
      'Haveri': 0.4,
      'Dharwad': 0.3,
      'Gadag': 0.2,
      'Koppal': 0.1,
      'Yadgir': 0.0,
      'Kalaburagi': 0.2,
      'Bidar': 0.1,
      'Chamarajanagar': 0.3,
      'Kodagu': 0.5
    };
    return factors[district] || 0.2;
  }

  private getClimateAdjustment(rainfall: number, temperature: number, humidity: number): number {
    const optimalRainfall = 800;
    const optimalTemp = 28;
    const optimalHumidity = 70;
    
    const rainfallScore = 1 - Math.abs(rainfall - optimalRainfall) / optimalRainfall;
    const tempScore = 1 - Math.abs(temperature - optimalTemp) / optimalTemp;
    const humidityScore = 1 - Math.abs(humidity - optimalHumidity) / optimalHumidity;
    
    return (rainfallScore + tempScore + humidityScore) / 3 * 0.2 - 0.1;
  }
}

export const predictionService = new PredictionService();